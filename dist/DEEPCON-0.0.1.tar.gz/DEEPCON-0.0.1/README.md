## DEEPCON: Protein Contact Prediction using Dilated Convolutional Neural Networks with Dropout  


#### Contact:
Email: adhikarib@umsl.edu  
Homepage: https://badriadhikari.github.io/  
Paper: https://www.biorxiv.org/content/10.1101/590455v1  

